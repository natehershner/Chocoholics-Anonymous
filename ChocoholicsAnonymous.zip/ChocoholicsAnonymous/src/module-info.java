module ChocoholicsAnonymous {
	exports GUI;
	requires transitive java.desktop;
	requires transitive java.sql;
}